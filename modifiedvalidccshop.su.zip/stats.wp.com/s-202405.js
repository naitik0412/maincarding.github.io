! function(e) {
    var t = {};

    function n(r) {
        if (t[r]) return t[r].exports;
        var o = t[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return e[r].call(o.exports, o, o.exports, n), o.l = !0, o.exports
    }
    n.m = e, n.c = t, n.d = function(e, t, r) {
        n.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: r
        })
    }, n.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, n.t = function(e, t) {
        if (1 & t && (e = n(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var r = Object.create(null);
        if (n.r(r), Object.defineProperty(r, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var o in e) n.d(r, o, function(t) {
                return e[t]
            }.bind(null, o));
        return r
    }, n.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return n.d(t, "a", t), t
    }, n.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, n.p = "", n(n.s = 6)
}([function(e, t) {
    function n(t) {
        return "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? e.exports = n = function(e) {
            return typeof e
        } : e.exports = n = function(e) {
            return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
        }, n(t)
    }
    e.exports = n
}, function(e, t, n) {
    "use strict";
    n.d(t, "b", (function() {
        return i
    })), n.d(t, "a", (function() {
        return u
    }));
    var r = null,
        o = function() {
            if (null == r) {
                r = "";
                var e, t = document.location.hostname.split(".");
                if ("undefined" != typeof TRACKS_COOKIE_DOMAIN) r = TRACKS_COOKIE_DOMAIN;
                else
                    for (var n = 1; n <= t.length; ++n)
                        if (e = "." + t.slice(-n).join("."), o = e, i = void 0, i = (new Date).getTime(), document.cookie = encodeURIComponent("tk_tc") + "=" + i + "; domain=" + o + "; path=/;", u("tc") == i) {
                            r = e;
                            break
                        }
                "" != r && (! function(e) {
                    var t = new Date;
                    t.setTime(t.getTime() - 1e3), document.cookie = encodeURIComponent("tk_tc") + "= ; domain=" + e + "; path=/; expires=" + t.toUTCString()
                }(r), r = "; domain=" + r)
            }
            var o, i;
            return r
        },
        i = function(e, t, n) {
            var r = encodeURIComponent("tk_" + e),
                i = new Date;
            void 0 === n && (n = 15768e4), document.location.hostname.match(/((^|\.)wp\.com$|^.?w\.org$)/) || (i.setTime(i.getTime() + 1e3 * n), document.cookie = r + "=" + encodeURIComponent(t) + o() + "; path=/; expires=" + i.toUTCString())
        },
        u = function(e) {
            var t = encodeURIComponent("tk_" + e) + "=",
                n = t.length,
                r = document.cookie.split("; "),
                o = r.length;
            for (1 === o && (o = (r = document.cookie.split(";")).length), o--; o >= 0; o--)
                if (r[o].substring(0, n) === t) return decodeURIComponent(r[o].substring(n));
            return null
        }
}, function(e, t, n) {
    "use strict";
    n.d(t, "a", (function() {
        return U
    }));
    var r = n(0),
        o = n.n(r),
        i = n(1);

    function u(e) {
        var t = [];
        if (window.crypto && window.crypto.getRandomValues) t = new Uint8Array(e), window.crypto.getRandomValues(t);
        else
            for (var n = 0; n < e; ++n) t[n] = Math.floor(256 * Math.random());
        return btoa(String.fromCharCode.apply(String, t))
    }
    var a, c, l, f, s, p, d, g;

    function v() {
        a = void 0, c = null, l = null, [], f = null, s = {}, p = {}, d = {}, g = {}
    }
    v();
    var m = function(e) {
        if (this.a = 1, e && e.length)
            for (var t = 0; t < e.length; t++) this.push(e[t])
    };
    m.prototype.push = function(e) {
        if (e)
            if ("object" == o()(e) && e.length) {
                var t = e.splice(0, 1);
                I[t] && I[t].apply(null, e)
            } else "function" == typeof e && e()
    };
    var y = function(e) {
            e._ui || e._ut || k(), j(), e._ui = e._ui || a, e._ut = e._ut || c, l && (e._ul = l);
            var t = new Date;
            e._ts = t.getTime(), e._tz = t.getTimezoneOffset() / 60;
            var n = window.navigator,
                r = window.screen;
            e._lg = n.language, e._pf = n.platform, e._ht = r.height, e._wd = r.width;
            var i = void 0 !== window.pageXOffset ? window.pageXOffset : (document.documentElement || document.body.parentNode || document.body).scrollLeft,
                u = void 0 !== window.pageYOffset ? window.pageYOffset : (document.documentElement || document.body.parentNode || document.body).scrollTop;
            e._sx = void 0 !== i ? i : 0, e._sy = void 0 !== u ? u : 0, void 0 !== document.location && (e._dl = document.location.toString()), void 0 !== document.referrer && (e._dr = document.referrer),
                function e(t, n) {
                    if (null == t || "object" !== o()(t)) return t;
                    for (var r in null != n && "object" === o()(n) || (n = t.constructor()), t) t.hasOwnProperty(r) && (n[r] = e(t[r]));
                    return n
                }(p, e), b(function(e) {
                    var t = [];
                    for (var n in e) e.hasOwnProperty(n) && t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e[n]));
                    return t.join("&")
                }(e), e.use_beacon || !1)
        },
        b = function(e, t) {
            if (!navigator.userAgent.match(/wp-e2e-tests|bingbot|bot|borg|google(^tv)|yahoo|slurp|msnbot|msrbot|openbot|archiver|netresearch|lycos|scooter|altavista|teoma|gigabot|baiduspider|blitzbot|oegp|charlotte|furlbot|http%20client|polybot|htdig|ichiro|mogimogi|larbin|pompos|scrubby|searchsight|seekbot|semanticdiscovery|silk|snappy|speedy|spider|voila|vortex|voyager|zao|zeal|fast\-webcrawler|converacrawler|dataparksearch|findlinks|crawler|Netvibes|Sogou Pic Spider|ICC\-Crawler|Innovazion Crawler|Daumoa|EtaoSpider|A6\-Indexer|YisouSpider|Riddler|DBot|wsr\-agent|Xenu|SeznamBot|PaperLiBot|SputnikBot|CCBot|ProoXiBot|Scrapy|Genieo|Screaming Frog|YahooCacheSystem|CiBra|Nutch/) && !(e in d))
                if (d[e] = !0, window.fetch && t) w(e), fetch("//pixel.wp.com/t.gif?" + e + "&_rt=" + (new Date).getTime() + "&_=_", {
                    mode: "no-cors",
                    keepalive: !0
                }).then((function() {
                    _(e)
                }));
                else {
                    var n = new Image;
                    w(e), n.query = e, n.onload = function() {
                        delete d[e], n && _(n.query)
                    }, n.src = "//pixel.wp.com/t.gif?" + e + "&_rt=" + (new Date).getTime() + "&_=_", n.alt = ""
                }
        },
        w = function(e) {
            var t, n = O();
            for (t = 0; t < n.length; ++t)
                if (e == n[t]) return;
            n.push(e), h(n)
        },
        h = function(e) {
            for (; e.join(" ").length > 2048;) e = e.slice(1);
            C("qs", e.join(" "), 1800)
        },
        _ = function(e) {
            var t, n = [],
                r = O();
            for (t = 0; t < r.length; ++t) e != r[t] && n.push(r[t]);
            n.length !== r.length && h(n)
        },
        O = function() {
            var e = x("qs");
            return e ? e.split(" ") : []
        },
        j = function() {
            null === f && (f = window.setTimeout((function() {
                O().forEach((function(e) {
                    b(e, !1)
                })), f = null
            }), 100))
        },
        S = function() {
            return u(18)
        },
        x = function(e) {
            return Object(i.a)(e) || s[e]
        },
        C = function(e, t, n) {
            s[e] = n <= -1 ? null : t, Object(i.b)(e, t, n)
        },
        P = function() {
            var e = [],
                t = x("ai"),
                n = x("aip");
            return n && (e = n.split(",")), t && e.push(t), e
        },
        k = function() {
            var e = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0];
            if (!a) {
                var t = x("ai");
                t ? (a = t, c = "anon") : e && (a = S(), c = "anon", C("ai", a))
            }
        },
        I = {
            storeContext: function(e) {
                "object" === o()(e) && (p = e)
            },
            identifyUser: function(e, t) {
                if (t && (l = t), "0" != e && "" != e && null != e && a != e) {
                    a = e, c = "wpcom:user_id";
                    for (var n = P(), r = 0; r < n.length; r++) y({
                        _en: "_aliasUser",
                        anonId: n[r]
                    });
                    var o = x("ai");
                    o && y({
                        _en: "_aliasUserGeneral",
                        nextuserid: a,
                        nextuseridtype: c,
                        prevuserid: o,
                        prevuseridtype: "anon"
                    }), C("ai", "", -1), C("aip", "", -1)
                }
            },
            identifyAnonUser: function(e) {
                if (k(!1), a != e)
                    if ("anon" === c || null === c) {
                        if ("anon" == c && a) {
                            var t = x("aip");
                            t = t ? t.split(",") : [];
                            for (var n = !1, r = 0; r < t.length; r++) a == t[r] && (n = !0);
                            n || (t.push(a), C("aip", t.join(",")), y({
                                _en: "_aliasUserGeneral",
                                nextuserid: e,
                                nextuseridtype: "anon",
                                prevuserid: a,
                                prevuseridtype: "anon"
                            }))
                        }
                        C("ai", e), a = e, c = "anon"
                    } else y({
                        _en: "_aliasUser",
                        anonId: e
                    })
            },
            recordEvent: function(e, t, n) {
                "_setProperties" !== e && ((t = t || {})._en = e, "string" == typeof n && n.length > 0 && (g[n] || (g[n] = u(18)), t._ui = t._ui || g[n], t._ut = t._ut || "anon"), y(t))
            },
            setProperties: function(e) {
                e._en = "_setProperties", y(e)
            },
            clearIdentity: function() {
                a = null, l = null, C("ai", "", -1), C("aip", "", -1), k()
            },
            signalAliasUserGeneral: function(e, t) {
                k(), y({
                    _en: "_aliasUserGeneral",
                    nextuserid: a,
                    nextuseridtype: c,
                    prevuserid: e,
                    prevuseridtype: t
                })
            }
        };

    function U() {
        return v(), window._tkq = window._tkq || [], window._tkq.a || (j(), window._tkq = new m(window._tkq)), I
    }
}, function(e, t, n) {
    var r = n(7);
    e.exports = function(e, t) {
        if (null == e) return {};
        var n, o, i = r(e, t);
        if (Object.getOwnPropertySymbols) {
            var u = Object.getOwnPropertySymbols(e);
            for (o = 0; o < u.length; o++) n = u[o], t.indexOf(n) >= 0 || Object.prototype.propertyIsEnumerable.call(e, n) && (i[n] = e[n])
        }
        return i
    }
}, function(e, t) {
    e.exports = function(e, t, n) {
        return t in e ? Object.defineProperty(e, t, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = n, e
    }
}, function(e) {
    e.exports = JSON.parse('{"errors":false}')
}, function(e, t, n) {
    e.exports = n(9)
}, function(e, t) {
    e.exports = function(e, t) {
        if (null == e) return {};
        var n, r, o = {},
            i = Object.keys(e);
        for (r = 0; r < i.length; r++) n = i[r], t.indexOf(n) >= 0 || (o[n] = e[n]);
        return o
    }
}, , function(e, t, n) {
    "use strict";
    n.r(t);
    var r = n(3),
        o = n.n(r),
        i = n(4),
        u = n.n(i),
        a = n(1),
        c = n(5),
        l = function(e) {
            if (c.errors) throw new Error(e)
        };
    var f = function(e) {
            return 0 === e.indexOf("".concat(location.protocol, "//").concat(location.host))
        },
        s = n(2);

    function p(e, t) {
        var n = Object.keys(e);
        if (Object.getOwnPropertySymbols) {
            var r = Object.getOwnPropertySymbols(e);
            t && (r = r.filter((function(t) {
                return Object.getOwnPropertyDescriptor(e, t).enumerable
            }))), n.push.apply(n, r)
        }
        return n
    }
    var d, g, v = (d = function(e) {
        var t = {
            update: function() {
                var n = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : document.referrer;
                if (window._wca_prevent_referrer) return !1;
                var r = 31536e3,
                    o = !0,
                    i = !0;
                return !f(n) && (t.getOriginal() || (o = e.set("or", n, 5 * r)), t.getAttWindow(3) || (i = t.setAttWindow(n, 3)), o && i && e.set("lr", n, r))
            },
            getLatest: function() {
                return e.get("lr")
            },
            getOriginal: function() {
                return e.get("or")
            },
            removeOldReferrers: function() {
                e.set("ro", "", -1), e.set("rl", "", -1)
            },
            setAttWindow: function(t, n) {
                return e.set("r".concat(n, "d"), t, 86400 * n)
            },
            getAttWindow: function(t) {
                return e.get("r".concat(t, "d"))
            }
        };
        return t
    }({
        get: function(e) {
            try {
                var t = Object(a.a)(e);
                return t = t ? JSON.parse(t) : null
            } catch (e) {
                return l(e), null
            }
        },
        set: function(e, t, n) {
            try {
                return t = JSON.stringify(t), Object(a.b)(e, t, n), !0
            } catch (e) {
                return l(e), !1
            }
        },
        remove: function(e) {
            try {
                return Object(a.b)(e, null), !0
            } catch (e) {
                return l(e), !1
            }
        }
    }), g = Object(s.a)(), d.removeOldReferrers(), d.update(), {
        push: function(e) {
            if (e) {
                var t = function(e) {
                        for (var t = 1; t < arguments.length; t++) {
                            var n = null != arguments[t] ? arguments[t] : {};
                            t % 2 ? p(Object(n), !0).forEach((function(t) {
                                u()(e, t, n[t])
                            })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : p(Object(n)).forEach((function(t) {
                                Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(n, t))
                            }))
                        }
                        return e
                    }({}, e, {
                        lr: d.getLatest(),
                        or: d.getOriginal(),
                        r3d: d.getAttWindow(3)
                    }),
                    n = t._en,
                    r = o()(t, ["_en"]);
                g.recordEvent(n, r)
            }
        }
    });
    Array.isArray(window._wca) && window._wca.forEach((function(e) {
        v.push(e)
    })), window._wca = v
}]);